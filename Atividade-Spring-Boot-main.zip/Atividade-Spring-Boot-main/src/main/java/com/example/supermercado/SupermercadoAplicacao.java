package com.example.supermercado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SupermercadoAplicacao {
    public static void main(String[] args) {
        SpringApplication.run(SupermercadoAplicacao.class, args);
    }
}

